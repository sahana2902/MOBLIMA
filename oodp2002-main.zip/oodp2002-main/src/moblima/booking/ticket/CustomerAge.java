package moblima.booking.ticket;

/**
 * Represents the Age category of a movie-goer
 */
public enum CustomerAge {
    CHILD,
    ADULT,
    SENIOR
}
