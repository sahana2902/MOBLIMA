package moblima.cineplex.cinema;

/**
 * Represents the class level of a cinema hall
 */
public enum CinemaClass {
    NORMAL,
    GOLD,
    PLATINUM;
}
