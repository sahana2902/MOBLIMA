package gui;

/**
 * Displayed at start of program
 */
public class GreetUserMenu implements Menu {
    /**
     * Prints welcome message
     */
    public void display(){
        System.out.println("Hello I'm MOBLIMA");
        System.out.println("I am a movie booking & listing management application!");
    }

}
