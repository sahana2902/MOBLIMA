package gui;

/**
 * Menu for the respective GUIs
 */
public interface Menu {
    /**
     * Prints menu
     */
    void display();
}
